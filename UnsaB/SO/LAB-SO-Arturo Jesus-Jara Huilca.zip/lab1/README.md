Explicacion del Laboratoio:

(producer.c ):
 	1) crear unicamente un solo proceso.
 	2) repetir el paso 1)* mediante un while infinito
 	3) capturar la hora he imprimirla

(consumer.c):
	1) un while infinito que reciba todos los procesos creados
	2) capturar la hora he imprimirla
